# for GUI
import tkinter as tk
from tkinter import *
from tkinter import filedialog
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import Image, ImageTk
############

# for machine learning
import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore', category = RuntimeWarning)
import os
import sklearn
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import KMeans
from sklearn.datasets import make_classification
from numpy import unique
from numpy import where
import datetime
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_squared_error
from scipy import stats
######################

# Machine learning

def data_preparation(data):
    data_weather = pd.read_csv(data, sep=",", header=None)
    data_weather = pd.DataFrame(data_weather.values[1:], columns=["Times","Irradiation"])
    data_weather['Times'] = pd.to_datetime(data_weather['Times'])


    df_weather = [0]*30

    for d in range(30):
        df_w = data_weather[d*12*24:(d+1)*12*24]
        df_new = [0]*24
        for i in range(24):
            df_new[i] = np.mean(df_w[12*i:12*i+1]["Irradiation"])
        df_weather[d] = df_new
        

    # prepare weather data: irradiation per hour
    df_weather_per_hour = [0]*720
    df_time = [0]*720
    counter = 0
    for d in range(30):
        irradiation = data_weather[d*12*24:(d+1)*12*24]
        irradiation2 = data_weather[d*12*24:(d+1)*12*24]["Times"]
        for i in range(24):
            string_time = irradiation2[i*12:i*12+1].to_string(index=False)
            df_time[counter] = string_time
            df_weather_per_hour[counter] = np.mean(irradiation[12*i:12*i+1]["Irradiation"])

            counter = counter+1

    # prepare data: overall production per hour
    df_prod_per_hour = [0]*720
    counter = 0
    for d in range(30):
        days = data_production[data_production["day"]==d+1]
        for h in range(24):
            df_prod_per_hour[counter] = sum(days[days["time"]== h+1].production)
            counter = counter+1
    # test for last day to final predict
    # val and train for training and validation

    # combine irradiation and production
    d = {'time': df_time, 'production': df_prod_per_hour, 'irradiation': df_weather_per_hour }
    df_prod_irr_per_h = pd.DataFrame(data=d)
    df_prod_irr_per_h['time'] = pd.to_datetime(df_prod_irr_per_h['time'])

    training = df_prod_irr_per_h[0:695]
    test = df_prod_irr_per_h[696:720]
    train, val = train_test_split(training, random_state = 111, test_size=0.15)

    return (training, test, train, val)
        
#GUI
######################################

def clicked1():
    file = filedialog.askopenfilename()
    training, test, train, val = data_preparation(file)
    predict_single_household_production_dtr(int(E1.get()), test['irradiation'], training, test)

def clicked2():
    file = filedialog.askopenfilename()
    training, test, train, val = data_preparation(file)
    predict_overall_production(test['irradiation'], train, test)

def predict_single_household_production_dtr(household, weatherdata, training, test):
    if len(weatherdata) == 0:
        df_w = test['irradiation']
    else: 
        df_w = weatherdata

    df_p = data_production[data_production["pv_id"]== household][:695].production
    
    dtr_single=DecisionTreeRegressor(max_depth = 4)

    dtr_single.fit(X = np.array(training.irradiation).reshape(-1, 1), y = df_p)

    predictions_dtr = dtr_single.predict(np.array(df_w).reshape(-1, 1))
    
    original_production = df_p = data_production[data_production["pv_id"]== household][695:719].production
    original_prod = np.array(original_production)
    
    # creating a 95% confidence interval
    sum_errs = np.sum((predictions_dtr - original_prod)**2)
    stdev = np.sqrt(1/(len(original_prod)-2) * sum_errs)
    # finding a 95% interval
    # z is 1.96 when we want there to be 95% certainty
    z = 1.96
    interval = z * stdev
    
    plt.errorbar(np.array(range(24)), predictions_dtr, yerr=interval, fmt='none', ecolor='b', capsize=2)
    plt.plot(predictions_dtr)
    plt.plot(original_prod)
 
    data1 = {
         'Predictions': predictions_dtr
        }
    df1 = pd.DataFrame(data1,columns=['Predictions'])

    data2 = {
         'Original Production': original_prod
        }
    df2 = pd.DataFrame(data2,columns=['Original Production'])

    root = tk.Tk()

    figure = plt.Figure(figsize=(7,4), dpi=100)
    ax = figure.add_subplot(111)
    line = FigureCanvasTkAgg(figure, root)
    line.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
    df1.plot(kind='line', ax=ax, legend=True, color='r', fontsize=10)
    df2.plot(kind='line', ax=ax, legend=True, color='b', fontsize=10)
    ax.set_title(f'Solar production forecast for nr {household} household based on the last 30 days')
    ax.set_xlabel('Hours (h)')
    ax.set_ylabel('Production (kWh)')
    ax.errorbar(np.array(range(24)), predictions_dtr, yerr=interval, fmt='none', ecolor='r', capsize=2)
    ax.grid()

    return predictions_dtr

def predict_overall_production(weatherdata, train, test):

    if len(weatherdata) == 0:
        df_w = test['irradiation']
    else: 
        df_w = weatherdata

    dtr=DecisionTreeRegressor(max_depth = 4)

    dtr.fit(X = np.array(train.irradiation).reshape(-1, 1), y = train.production)

    #dtr_score = dtr.score(val[['irradiation']], val[['production']])
    #print('The prediction has a score of: ', dtr_score)
    
    predictions_dtr = dtr.predict(np.array(df_w).reshape(-1, 1))
    original_prod = np.array(test['production'])

    root = tk.Tk()

    data1 = {
         'Predictions': predictions_dtr
        }
    df1 = pd.DataFrame(data1,columns=['Predictions'])

    data2 = {
         'Original Production': original_prod
        }
    df2 = pd.DataFrame(data2,columns=['Original Production'])
    figure = plt.Figure(figsize=(7,4), dpi=100)
    ax = figure.add_subplot(111)
    line = FigureCanvasTkAgg(figure, root)
    line.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
    df1.plot(kind='line', ax=ax, legend=True, color='r', fontsize=10)
    df2.plot(kind='line', ax=ax, legend=True, color='b', fontsize=10)
    ax.set_title('Overall Prediction based on DecisionTreeRegressor')
    ax.set_xlabel('Hours (h)')
    ax.set_ylabel('Production (kWh)')
    ax.grid()
                
    return predictions_dtr

def household_clustering():
    df_prod = [0]*100
    for i in range(100):
        df_prod[i] = data_production[data_production["pv_id"]==i]
        df_day = [0]*30
        for d in range(30):
            df_day[d] = np.sum(df_prod[i][df_prod[i]["day"]==d].production)
        df_prod[i] = np.sum(df_day)

    # cluster of daily production per household (aggregative clustering)

    d = {'latitude': data_location["latitude"], 'longitude': data_location["longitude"]}
    df_loc = pd.DataFrame(data=d)
    df_prod = np.reshape(df_prod, (-1, 1))
    agg_clustering = AgglomerativeClustering(n_clusters=10).fit(df_prod)
    labels = agg_clustering.labels_
    colours = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']

    
    root = tk.Tk()

    figure = plt.Figure(figsize=(7,4), dpi=100)
    ax = figure.add_subplot(111)
    line = FigureCanvasTkAgg(figure, root)
    line.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)

    for row in range(100):
        ax.scatter(df_loc["latitude"][row],df_loc["longitude"][row], c=colours[labels[row]])
    
    
    ax.set_title('Overall Prediction based on DecisionTreeRegressor')
    ax.set_xlabel('Latitude (°)')
    ax.set_ylabel('Longitude (°)')
    ax.grid()

window = Tk()
window.geometry('700x400')
window.title("Welcome to our Solar Predictor!")

#some data
data_production = pd.read_csv("pv_production_new.csv")
data_location = pd.read_csv("pv_locations.csv")
##
image1 = Image.open("sky2.jpg")
test = ImageTk.PhotoImage(image1)

label1 = tk.Label(image=test)
label1.image = test

# Position image
label1.place(x=0, y=0, relwidth=1, relheight=1)

text1 = Label(window, font=("Bolt", 12), justify='left', text = 'Upload a file with historical data to:\nGenerate a graph with next 24 hours solar production\nprediction of a single household (nr 1-100) with confidence intervals')
text1.place(x= 30, y=25)

L1 = Label(window, text="Household number: ", font=("Bolt", 10))
L1.place(x=60, y=100)

E1 = Entry(window, width=5)
E1.place(x=190, y=103)

btn1 = Button(window, text="Single household", font=("Bolt", 12), command = clicked1)
btn1.place(x=60, y=130)

text2 = Label(window, font=("Bolt", 12), justify='left', text ='Generate a graph with overall production based on DecisionTreeRegressor.')
text2.place(x= 30, y=190)

btn2 = Button(window, text="Overall production",font=("Bolt", 12),  command = clicked2)
btn2.place(x= 60, y=230)

text3 = Label(window, font=("Bolt", 12), justify='left', text ='Generate a graph with cluster of daily production per household.')
text3.place(x= 30, y=300)

btn3 = Button(window, text="Household clustering",font=("Bolt", 12),  command = household_clustering)
btn3.place(x= 60, y=340)

window.mainloop()